$env:xconnect="d:\\src\\SC91\Runtime\\websites\\sc910.xconnect.local"

 
Copy-Item -Path "sc.Demo.GoalsProjectionModel.Models.xml" -Destination "$Env:xconnect\\App_Data\\jobs\\continuous\\ProcessingEngine\\App_Data\\Config\\Sitecore\\Processing" -Force
Copy-Item -Path "sc.Demo.Processing.Engine.ML.Workers.xml" -Destination "$Env:xconnect\\App_Data\\jobs\\continuous\\ProcessingEngine\\App_Data\\Config\\Sitecore\\Processing" -Force
Copy-Item -Path "sc.Demo.Processing.Services.MLNet.xml" -Destination "$Env:xconnect\\App_Data\\jobs\\continuous\\ProcessingEngine\\App_Data\\Config\\Sitecore\\Processing" -Force

Write-Output "The configuration files were copied successfully"

Copy-Item -Path "ContactModel, 1.0.json" -Destination "$Env:xconnect\\App_Data\\jobs\\continuous\\ProcessingEngine\\App_Data\\Models" -Force
Copy-Item -Path "ContactModel, 1.0.json" -Destination "$Env:xconnect\\App_Data\\Models" -Force
Copy-Item -Path "ContactModel, 1.0.json" -Destination "$Env:xconnect\\App_Data\\jobs\\continuous\\IndexWorker\\App_data\\Models" -Force
Copy-Item -Path "ContactModel, 1.0.json" -Destination "$Env:xconnect\\App_Data\\jobs\\continuous\\AutomationEngine\\App_Data\\Models" -Force

Write-Output "The 'ContactModel, 1.0.json' was copied successfully"
Write-Output "SUCCESS!!! You can close the window..."